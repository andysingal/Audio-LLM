# Speech to Text with Translation
# Written mostly by ChatGPT with prompting and debugging by Mike Young
# Last Update: Oct. 18, 2024

import pyaudio
import wave
import numpy as np
import whisper
from transformers import MarianMTModel, MarianTokenizer
import os
import datetime
import time
import sys
import subprocess

# Launch unclutter with the appropriate options (e.g., -idle 0)
subprocess.Popen(['unclutter', '-idle', '0', '-root'])

import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

# function to hide the cursor
def hide_cursor():
    sys.stdout.write('\033[?25l')
    sys.stdout.flush()

# function to show the cursor
def show_cursor():
    sys.stdout.write('\033[?25h')
    sys.stdout.flush()

# get the timestamp from command-line arguments
timestamp = sys.argv[1]

# constants -- set according to your use case

CHUNK = 1024               # number of audio frames per buffer
FORMAT = pyaudio.paInt16   # 16-bit audio
CHANNELS = 1               # mono audio
RATE = 16000               # sample rate (Hz)

constants = {}

# open config.txt to get user preferences as specified in that file
with open('config.txt', 'r') as file:
    for line in file:
        line = line.split('#', 1)[0].strip()   # ignore comments and strip whitespace
        if line:                               # only process non-empty lines
            key, value = line.split('=', 1)
            value = value.strip()             # remove any extra spaces

            # determine the type of value
            if value.isdigit():                       # check if it's an integer
                constants[key.strip()] = int(value)
            elif value.lower() in ['true', 'false']:               # check for boolean
                constants[key.strip()] = value.lower() == 'true'
            else:
                try: 
                    constants[key.strip()] = float(value)   # attempt to convert to float
                except ValueError:
                    constants[key.strip()] = value   # if it fails, just store as a string

# access the constants
SILENCE_THRESHOLD = constants['SILENCE_THRESHOLD']
SILENCE_DURATION = constants['SILENCE_DURATION']
MIN_AUDIO_DURATION = constants['MIN_AUDIO_DURATION']
MAX_AUDIO_DURATION = constants['MAX_AUDIO_DURATION']
OUTPUT_ENG = 1
OUTPUT_SPN = 1
OUTPUT_PARAMS = 1
OUTPUT_STMSG = 1
OUTPUT_ENG = constants['OUTPUT_ENG']
OUTPUT_SPN = constants['OUTPUT_SPN']
OUTPUT_PARAMS = constants['OUTPUT_PARAMS']
OUTPUT_STMSG = constants['OUTPUT_STMSG']
DISABLE_TRNSLTN = 0
DISABLE_TRNSLTN = constants['DISABLE_TRNSLTN']

# text colors
RED = "\033[91m"
GREEN = "\033[92m"
RESET = "\033[0m"

hide_cursor()   # hide the text cursor

# initialize Whisper tiny model
whisper_model = whisper.load_model("tiny")

# initialize Hugging Face translation model and tokenizer

translation_model_name = "Helsinki-NLP/opus-mt-en-es"

# example of translating to German instead of Spanish...
#translation_model_name = "Helsinki-NLP/opus-mt-en-de"

tokenizer = MarianTokenizer.from_pretrained(translation_model_name)
translation_model = MarianMTModel.from_pretrained(translation_model_name)

def translate_text(text):
    inputs = tokenizer(text, return_tensors="pt")
    outputs = translation_model.generate(**inputs)
    translated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return translated_text

def get_timestamp():
    now = datetime.datetime.now()
    return now.strftime("%Y-%m-%d_%I-%M%p")

def record_and_process_audio():
    audio = pyaudio.PyAudio()
    stream = audio.open(format=FORMAT,
                        channels=CHANNELS,
                        rate=RATE,
                        input=True,
                        frames_per_buffer=CHUNK)
    
    if OUTPUT_STMSG == 1:
        print(f"Listening... Press [Ctrl] + [C] to exit.\n")

    frames = []
    silent_chunks = 0
    total_chunks = 0
    start_time = time.time()
    file_counter = 1
    max_volume = 0;

    # open output files once at the beginning
    # note that timestamp is already computed and passed on by the bash script calling this Python script
    english_filename = f"english-{timestamp}.txt"
    spanish_filename = f"español-{timestamp}.txt"
    
    with open(english_filename, "a") as english_file, open(spanish_filename, "a") as spanish_file:
        try:
            while True:
                # record audio
                data = stream.read(CHUNK)
                frames.append(data)
                audio_data = np.frombuffer(data, dtype=np.int16)

                # if OUTPUT_PARAMS is 1 then output parameters to the terminal, which is handy for determining good values for thresholds and durations for a specific use case
                if OUTPUT_PARAMS == 1:
                    current_volume = np.max(np.abs(audio_data))
                    if current_volume > max_volume:
                        max_volume = current_volume 
                    formatted_output1 = f"{str(current_volume).rjust(5)}"
                    formatted_output2 = f"{str(max_volume).rjust(5)}"
                    print(f"CurrVol:{formatted_output1} | MaxVol:{formatted_output2} | SilThresh:{SILENCE_THRESHOLD} | SilDur:{SILENCE_DURATION}s | MinDur:{MIN_AUDIO_DURATION}s | MaxDur:{MAX_AUDIO_DURATION}s    ", end='\r')

                # check if audio is silent
                if np.max(np.abs(audio_data)) < SILENCE_THRESHOLD:
                    silent_chunks += 1
                else:
                    silent_chunks = 0
                total_chunks += 1

                #print(f"{silent_chunks} / {total_chunks}")    # was used for debugging

                # calculate duration of the audio chunk
                elapsed_time = time.time() - start_time
                if elapsed_time >= MAX_AUDIO_DURATION:
                    if len(frames) > 0:
                        # save recorded audio to a WAV file for later assembly as one large FLAC file
                        filename = f"{file_counter:08d}.wav"
                        file_counter += 1
                        with wave.open(filename, 'wb') as wf:
                            wf.setnchannels(CHANNELS)
                            wf.setsampwidth(pyaudio.PyAudio().get_sample_size(FORMAT))
                            wf.setframerate(RATE)
                            wf.writeframes(b''.join(frames))
                        #print(f"Saved {filename}")
                        #print(f"Processing audio...\n")

                        # save to a temporary WAV file for Whisper
                        temp_wav_file = "temp.wav"
                        with wave.open(temp_wav_file, 'wb') as wf:
                            wf.setnchannels(CHANNELS)
                            wf.setsampwidth(pyaudio.PyAudio().get_sample_size(FORMAT))
                            wf.setframerate(RATE)
                            wf.writeframes(b''.join(frames))
                        
                        # perform speech-to-text
                        #print(f"{silent_chunks}")          # was used for debugging
                        if silent_chunks != total_chunks:
                            max_volume = 0
                            result = whisper_model.transcribe(temp_wav_file, fp16=False)
                            text = result['text'].strip()
                            #print(len(text))
                            if len(text) != 0 and len(text) != 889:    # when length is 0 or 889 the text is garbage and should be discarded
                                if OUTPUT_PARAMS == 1:

                                    if OUTPUT_ENG == 1:
                                        if OUTPUT_SPN == 1:
                                            print(f"{RED}English:{RESET}                                                                                     \n{text}\n")
                                        else:
                                            print(f"                                                                                     \r{text}\n")

                                    # translate text to Spanish
                                    if DISABLE_TRNSLTN == 0:
                                        translated_text = translate_text(text)
                                    else:
                                        translated_text = ""
                                    if OUTPUT_SPN == 1:
                                        if OUTPUT_ENG == 1:
                                            print(f"{GREEN}Español:{RESET}                                                                                     \n{translated_text}\n")
                                        else:
                                            print(f"                                                                                     \r{translated_text}\n")

                                else:

                                    if OUTPUT_ENG == 1:
                                        if OUTPUT_SPN == 1:
                                            print(f"{RED}English:{RESET}\n{text}\n")
                                        else:
                                            print(f"{text}\n")

                                    # translate text to Spanish
                                    if DISABLE_TRNSLTN == 0:
                                        translated_text = translate_text(text)
                                    else:
                                        translated_text = ""
                                    if OUTPUT_SPN == 1:
                                        if OUTPUT_ENG == 1:
                                            print(f"{GREEN}Español:{RESET}\n{translated_text}\n")
                                        else:
                                            print(f"{translated_text}\n")

                                # append transcription and translation to files
                                english_file.write(text + "\n\n")
                                spanish_file.write(translated_text + "\n\n")

                        # reset for the next chunk
                        frames = []
                        start_time = time.time()  # reset timer for new chunk

                # save audio if silence exceeds defined duration
                if silent_chunks * (CHUNK / RATE) >= SILENCE_DURATION:
                    if len(frames) > 0:
                        # save recorded audio to a WAV file for later assembly as one large FLAC file
                        filename = f"{file_counter:08d}.wav"
                        file_counter += 1
                        with wave.open(filename, 'wb') as wf:
                            wf.setnchannels(CHANNELS)
                            wf.setsampwidth(pyaudio.PyAudio().get_sample_size(FORMAT))
                            wf.setframerate(RATE)
                            wf.writeframes(b''.join(frames))
                        #print(f"Saved {filename}")
                        #print(f"Processing audio...\n")

                        # save to a temporary WAV file for Whisper
                        temp_wav_file = "temp.wav"
                        with wave.open(temp_wav_file, 'wb') as wf:
                            wf.setnchannels(CHANNELS)
                            wf.setsampwidth(pyaudio.PyAudio().get_sample_size(FORMAT))
                            wf.setframerate(RATE)
                            wf.writeframes(b''.join(frames))
                        
                        # perform speech-to-text
                        #print(f"{silent_chunks}")          # was used for debugging
                        if silent_chunks != total_chunks:
                            max_volume = 0
                            result = whisper_model.transcribe(temp_wav_file, fp16=False)
                            text = result['text'].strip()
                            #print(len(text))
                            if len(text) != 0 and len(text) != 889:
                                if OUTPUT_PARAMS == 1:

                                    if OUTPUT_ENG == 1:
                                        if OUTPUT_SPN == 1:
                                            print(f"{RED}English:{RESET}                                                                                     \n{text}\n")
                                        else:
                                            print(f"                                                                                     \r{text}\n")

                                    # translate text to Spanish
                                    translated_text = translate_text(text)
                                    if OUTPUT_SPN == 1:
                                        if OUTPUT_ENG == 1:
                                            print(f"{GREEN}Español:{RESET}                                                                                     \n{translated_text}\n")
                                        else:
                                            print(f"                                                                                     \r{translated_text}\n")

                                else:

                                    if OUTPUT_ENG == 1:
                                        if OUTPUT_SPN == 1:
                                            print(f"{RED}English:{RESET}\n{text}\n")
                                        else:
                                            print(f"{text}\n")

                                    # translate text to Spanish
                                    translated_text = translate_text(text)
                                    if OUTPUT_SPN == 1:
                                        if OUTPUT_ENG == 1:
                                            print(f"{GREEN}Español:{RESET}\n{translated_text}\n")
                                        else:
                                            print(f"{translated_text}\n")

                                # append transcription and translation to files
                                english_file.write(text + "\n\n")
                                spanish_file.write(translated_text + "\n\n")

                        # reset for the next chunk
                        frames = []
                        silent_chunks = 0
                        total_chunks = 0
                        start_time = time.time()  # Reset timer for new chunk

        except KeyboardInterrupt:
            print("\nExiting...")

        finally:
            show_cursor()
            stream.stop_stream()
            stream.close()
            audio.terminate()
            if os.path.exists("temp.wav"):
                os.remove("temp.wav")

if __name__ == "__main__":
    record_and_process_audio()
