#!/bin/bash
shutdown now
