#!/bin/bash

# define the directory containing the WAV files (current directory)
DIR="."

# define the destinations for the flac and txt files.  First choice is USB flash drive named "output" and second choice is "output" folder in user home directory
destination1="/media/$USER/output"
destination2="/home/$USER/sttwt/output"

# define the file list and output file with the current timestamp
FILE_LIST="file_list.txt"

# timestamp is now computed by the bash script that calls this bash script
#TIMESTAMP=$(date +"%Y-%m-%d_%I-%M%p")
TIMESTAMP=$1

OUTPUT_FILE="english-${TIMESTAMP}.flac"

# create or clear the file list
> "$FILE_LIST"

# loop through all WAV files in the directory and add them to the file list
for FILE in "$DIR"/*.wav; do
    echo "file '$FILE'" >> "$FILE_LIST"
done

# use ffmpeg to concatenate the files and convert to FLAC
ffmpeg -f concat -safe 0 -i "$FILE_LIST" -c:a flac "$OUTPUT_FILE" > /dev/null 2>&1

# check if the concatenation was successful
if [ $? -eq 0 ]; then
    # delete the original WAV files if the concatenation was successful
    rm "$DIR"/*.wav
    #echo "Concatenation successful and WAV files deleted!"
else
    echo "Concatenation failed!  WAV files not deleted!"
fi

# clean up the file list
rm "$FILE_LIST"

# Not using flite as Spanish output doesn't seem supported, or at least I couldn't immediately figure out how to do it.  Using eSpeak NG instead for now.
#flite -voice spanish_cmu -f español-${TIMESTAMP}.txt -o output.wav

# still doing this, but suppressing output to the terminal
#espeak-ng -v es -s 150 -f "español-${TIMESTAMP}.txt" --stdout > output.wav
#ffmpeg -i output.wav español-${TIMESTAMP}.flac

espeak-ng -v es -s 150 -f "español-${TIMESTAMP}.txt" --stdout > output.wav 2>/dev/null
ffmpeg -i output.wav español-${TIMESTAMP}.flac > /dev/null 2>&1

rm output.wav

mkdir -p "$destination1"
mv e*.flac e*.txt -n "$destination1"
if [ $? -ne 0 ]; then
    mkdir -p "$destination2"
    mv e*.flac e*.txt -n "$destination2"
fi

#echo "Press any key to continue..."
#read -n 1 -s
