#!/bin/bash

# hide the mouse cursor
#unclutter -idle 0

# change directory into sttwt
cd sttwt

# generate the timestamp in the format YYYY-MM-DD_HH-MM[AM/PM]
timestamp=$(date +"%Y-%m-%d_%I-%M%p")

# activate the Python environment
source myenv/bin/activate

# run the Python script
python sttwt.py "$timestamp" 2>/dev/null

# call the wtf.sh script to process and output text files, process and output audio files, delete residual files, and move files accordingly
./wtf.sh "$timestamp"

# deactivate the Python environment
deactivate

# unhide the mouse cursor
killall unclutter
